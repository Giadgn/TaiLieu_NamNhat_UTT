#include<stdio.h>
#include<math.h>
int main (){
	int n ,x;
	float Q = 10;
	printf("Nhap so nguyen n: ");scanf("%d",&n);
	printf("Nhap so nguyen x: ");scanf("%d",&x);
	
}
